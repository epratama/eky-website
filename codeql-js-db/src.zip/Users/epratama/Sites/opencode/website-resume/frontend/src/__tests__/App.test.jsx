import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { readFileSync } from 'fs'
import { resolve } from 'path'
import App from '../components/App'

function getCspMetaContent() {
  const html = readFileSync(resolve(__dirname, '../../index.html'), 'utf-8')
  const match = html.match(/<meta[^>]*http-equiv="Content-Security-Policy"[^>]*content="([^"]*)"[^>]*>/)
  return match ? match[1] : ''
}

describe('App', () => {
  it('renders without crashing', () => {
    render(<App />)
    expect(screen.getByText('Eky Pratama')).toBeInTheDocument()
  })

  it('renders all section IDs for navbar scrolling', () => {
    render(<App />)
    expect(document.getElementById('home')).toBeInTheDocument()
    expect(document.getElementById('summary')).toBeInTheDocument()
    expect(document.getElementById('achievements')).toBeInTheDocument()
    expect(document.getElementById('experience')).toBeInTheDocument()
    expect(document.getElementById('skills')).toBeInTheDocument()
    expect(document.getElementById('education')).toBeInTheDocument()
    expect(document.getElementById('contact')).toBeInTheDocument()
  })

  it('renders the updated title', () => {
    render(<App />)
    const matches = screen.getAllByText('Technical Lead & Senior Software Engineer')
    expect(matches.length).toBeGreaterThanOrEqual(2)
  })

  it('renders experience entries in descending chronological order', () => {
    render(<App />)
    const section = document.getElementById('experience')
    const html = section.innerHTML
    const swiftPos = html.indexOf('Swift Digital')
    const internetrixPos = html.indexOf('Internetrix')
    expect(swiftPos).toBeLessThan(internetrixPos)
  })

  it('renders GitHub links in Hero and Footer', () => {
    render(<App />)
    const links = screen.getAllByRole('link', { name: /github/i })
    expect(links).toHaveLength(2)
    links.forEach((link) => {
      expect(link).toHaveAttribute('href', 'https://github.com/epratama')
    })
  })

  it('CSP allows favicon data URI, hCaptcha, and API Gateway connections', () => {
    const csp = getCspMetaContent()
    expect(csp).toContain("img-src 'self' data:")
    expect(csp).toContain('connect-src')
    expect(csp).toContain('*.hcaptcha.com')
    expect(csp).toContain('*.amazonaws.com')
    expect(csp).toContain("frame-src")
    expect(csp).toContain("form-action 'self'")
  })
})
